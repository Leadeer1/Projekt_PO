﻿using static WypozyczalniaGier.Wypozyczalnia;

namespace WypozyczalniaGier
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            
            Wypozyczalnia wypozyczalnia = new Wypozyczalnia();

            
            wypozyczalnia.DodajGre(new Gra("Gra 1", "Przygodowa", 5));
            wypozyczalnia.DodajGre(new Gra("Gra 2", "Akcja", 3));
            wypozyczalnia.DodajGre(new Gra("Gra 3", "Strategia", 7));

            
            Console.WriteLine("Oryginalne gry:");
            wypozyczalnia.WyswietlGry();

            
            Gra oryginalnaGra = wypozyczalnia.ZnajdzGre("Gra 1");
            Gra sklonowanaGra = (Gra)oryginalnaGra.Clone();

            
            sklonowanaGra.Tytul = "Gra 1 - Edycja Specjalna";
            sklonowanaGra.Dostepnosc = 2;

            
            Console.WriteLine("\nOryginalna gra i jej klon:");
            oryginalnaGra.ShowInfo();
            sklonowanaGra.ShowInfo();

            
            Console.WriteLine("\nPorównanie gier:");
            Console.WriteLine($"Czy 'Gra 1' i jej klon są takie same? {oryginalnaGra.Equals(sklonowanaGra)}");

            
            wypozyczalnia.DodajKlienta(new Klient("Jan", "Kowalski"));
            wypozyczalnia.DodajKlienta(new Klient("Anna", "Nowak"));

           
            Klient klient = wypozyczalnia.ZnajdzKlienta(1);
            Rezerwacja rezerwacja = new Rezerwacja(oryginalnaGra, klient, DateTime.Now, null);
            wypozyczalnia.DodajRezerwacje(rezerwacja);

            
            Console.WriteLine("\nRezerwacje:");
            wypozyczalnia.WyswietlRezerwacje();

            TextGUI(wypozyczalnia);
        }
        private static void TextGUI(Wypozyczalnia system)
        {
            while (true)
            {
                Console.WriteLine("\nSystem Wypożyczalni Gier Planszowych");
                Console.WriteLine("1. Wyświetl gry"); 
                Console.WriteLine("2. Wyświetl klientów"); 
                Console.WriteLine("3. Wyświetl rezerwacje"); 
                Console.WriteLine("4. Dodaj nową grę"); 
                Console.WriteLine("5. Dodaj nową rezerwację"); 
                Console.WriteLine("5. Zwróć grę (zakończ rezerwację)"); 
                Console.WriteLine("6. Zapisz dane do pliku"); 
                Console.WriteLine("7. Wczytaj dane z pliku"); 
                Console.WriteLine("8. Wywołanie funkcji dodającej przykładowe dane");
                Console.WriteLine("9. Usuń klienta");
                Console.WriteLine("10. Usuń grę");
                Console.WriteLine("11. Usuń rezerwację");
                Console.WriteLine("0. Wyjdź");
                Console.Write("Wybierz opcję: ");

                var wybor = Console.ReadLine();

                try
                {
                    switch (wybor)
                    {
                        case "1":
                            system.WyswietlGry();
                            break;
                        case "2":
                            system.WyswietlKlientow();
                            break;
                        case "3":
                            system.WyswietlRezerwacje();
                            break;
                        case "4":
                            Console.Write("Podaj tytuł gry: ");
                            var tytul = Console.ReadLine();
                            Console.Write("Podaj gatunek gry: ");
                            var gatunek = Console.ReadLine();
                            Console.Write("Podaj liczbę egzemplarzy: ");
                            var liczbaEgzemplarzy = int.Parse(Console.ReadLine());
                            system.DodajGre(new Gra(tytul, gatunek, liczbaEgzemplarzy));
                            Console.WriteLine("Gra została dodana.");
                            break;
                        case "5":
                            Console.WriteLine("Wybierz klienta (podaj ID) lub wpisz 'nowy', aby dodać nowego klienta:");
                            system.WyswietlKlientow();
                            var input = Console.ReadLine();

                            Klient klient;
                            if (input.ToLower() == "nowy")
                            {
                                Console.Write("Podaj imię: ");
                                var imie = Console.ReadLine();
                                Console.Write("Podaj nazwisko: ");
                                var nazwisko = Console.ReadLine();
                                klient = new Klient(imie, nazwisko);
                                system.DodajKlienta(klient);
                            }
                            else
                            {
       
                                var idIn = int.Parse(input);
                                klient = system.ZnajdzKlienta(idIn);

                                if (klient == null)
                                {
                                    Console.WriteLine($"Nie znaleziono klienta o ID: {idIn}");
                                    break; 
                                }
                            }

                            Console.WriteLine("Wybierz grę (podaj tytuł):");
                            system.WyswietlGry();
                            var tytulGry = Console.ReadLine();
                            var gra = system.ZnajdzGre(tytulGry);

                            system.DodajRezerwacje(new Rezerwacja(gra, klient, DateTime.Now, null));
                            gra.Dostepnosc--;
                            klient.liczbaWypozyczen++;
                            break;
                        case "6":
                            Console.Write("Podaj ścieżkę do zapisu danych: ");
                            string sciezkaZapisu = Console.ReadLine();
                            if(sciezkaZapisu == "") { sciezkaZapisu = "plik.json"; }
                            system.ZapiszDane(sciezkaZapisu);
                            break;
                        case "7":
                            Console.Write("Podaj ścieżkę do odczytu danych: ");
                            string sciezkaOdczytu = Console.ReadLine();
                            if (sciezkaOdczytu == "") { sciezkaOdczytu = "plik.json"; }
                            system.WczytajDane(sciezkaOdczytu);
                            break;
                        case "8":
                            TestGier(system);
                            break;
                        case "9":
                            Console.WriteLine("Podaj ID klienta do usunięcia: ");
                            var inputId = Console.ReadLine();
                            var id = int.Parse(inputId);
                            klient = system.ZnajdzKlienta(id);

                            if (klient == null)
                            {
                                Console.WriteLine($"Nie znaleziono klienta o ID: {id}");
                                break;
                            }

                            var rezerwacjeKlienta = system.Rezerwacje.Any(r => r.KlientR.IdKlienta == klient.IdKlienta);
                            if (rezerwacjeKlienta)
                            {
                                Console.WriteLine($"Nie można usunąć klienta o ID: {id}, ponieważ istnieją powiązane rezerwacje.");
                                break;
                            }

                            system.UsunKlienta(system.Klienci[id - 1]);
                            Console.WriteLine("Klient usunięty!");
                            break;

                        case "10":
                            Console.WriteLine("Podaj ID gry do usunięcia: ");
                            inputId = Console.ReadLine();
                            id = int.Parse(inputId);
                            gra = system.ZnajdzGre(system.Gry[id-1].Tytul);

                            if (gra == null)
                            {
                                Console.WriteLine($"Nie znaleziono gry o ID: {id}");
                                break;
                            }
                            var rezerwacjeGry = system.Rezerwacje.Any(r => r.GraR.Tytul == gra.Tytul);
                            if (rezerwacjeGry)
                            {
                                Console.WriteLine($"Nie można usunąć gry o ID: {id}, ponieważ istnieją powiązane rezerwacje.");
                                break;
                            }
                            
                            system.UsunGre(system.Gry[id - 1]);
                            Console.WriteLine("Gra usunięta!");
                            break;
                        case "11":
                            Console.WriteLine("Podaj ID rezerwacji do usunięcia: ");
                            inputId = Console.ReadLine();
                            id = int.Parse(inputId);
                            Rezerwacja rezerwacja = system.Rezerwacje[id-1];

                            if (rezerwacja == null)
                            {
                                Console.WriteLine($"Nie znaleziono rezerwacji o ID: {id}");
                                break;
                            }
                            else
                            {
                                system.UsunRezerwacje(system.Rezerwacje[id-1]);
                                Console.WriteLine("Rezerwacja usunięta!");
                            }
                            break;
                        case "0":
                            Console.WriteLine("Zamykam program...");
                            return;
                        default:
                            Console.WriteLine("Nieprawidłowa opcja, spróbuj ponownie.");
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Błąd: {ex.Message}");
                }
            }
        }

        private static void TestGier(Wypozyczalnia system)
        {
            try
            {
               
                system.DodajGre(new Gra("Catan", "Strategia", 3));
                system.DodajGre(new Gra("Dixit", "Imprezowa", 2));

                system.DodajKlienta(new Klient("Jan", "Kowalski"));
                system.DodajKlienta(new Klient("Anna", "Nowak"));

                var gra = new Gra("Catan", "Strategia", 3);
                var klient = system.ZnajdzKlienta(1);
                system.DodajRezerwacje(new Rezerwacja(gra, klient, DateTime.Now, null));

                system.ZapiszDane("dane.json");

                system.WczytajDane("dane.json");


            }
            catch (BrakEgzemplarzyException ex)
            {
                Console.WriteLine($"Błąd: {ex.Message}");
            }
            catch (ObiektNieznalezionyException ex)
            {
                Console.WriteLine($"Błąd: Nie ma takiego klienta");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Nieoczekiwany błąd: {ex.Message}");
            }
        }
    }
}
