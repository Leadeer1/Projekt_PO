﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WypozyczalniaGier
{
    /// <summary>
    /// Reprezentuje klienta wypożyczalni gier. Klient dziedziczy po klasie <see cref="Osoba"/>
    /// i implementuje interfejs <see cref="IComparable{Klient}"/>.
    /// </summary>
    [Serializable]
    public class Klient : Osoba, IComparable<Klient>
    {
        /// <summary>
        /// Statyczny licznik do generowania unikalnych ID klientów.
        /// </summary>
        private static int nextId = 1;

        /// <summary>
        /// Liczba wypożyczeń dokonanych przez klienta.
        /// </summary>
        public int liczbaWypozyczen = 1;

        /// <summary>
        /// Unikalne ID klienta.
        /// </summary>
        public int IdKlienta { get; set; }

        /// <summary>
        /// Określa, czy klient ma aktywne wypożyczenie.
        /// </summary>
        public bool IsActive { get; set; }

        /// <summary>
        /// Konstruktor domyślny dla klienta, inicjalizuje ID, aktywność oraz liczbę wypożyczeń.
        /// </summary>
        public Klient()
        {
            IsActive = false;
            IdKlienta = nextId;
            nextId++;
            liczbaWypozyczen = 1;
        }

        /// <summary>
        /// Konstruktor, który przyjmuje imię i nazwisko klienta, dziedziczy po klasie <see cref="Osoba"/>.
        /// </summary>
        /// <param name="imie">Imię klienta.</param>
        /// <param name="nazwisko">Nazwisko klienta.</param>
        public Klient(string imie, string nazwisko) : base(imie, nazwisko)
        {
            IsActive = false;
            IdKlienta = nextId;
            nextId++;
        }

        /// <summary>
        /// Wyświetla informacje o kliencie, takie jak ID, imię, nazwisko oraz status aktywności.
        /// Jeśli klient ma aktywne wypożyczenie, wyświetla liczbę wypożyczeń.
        /// </summary>
        public override void ShowInfo()
        {
            string aktywnosc = IsActive ? "Tak" : "Nie";
            Console.Write($"Klient - ID: {IdKlienta}, Imię: {Imie}, Nazwisko: {Nazwisko}, Aktywne wypożyczenia: {aktywnosc}");
            if (IsActive)
            {
                Console.WriteLine($" ({liczbaWypozyczen})");
            }
            else
            {
                Console.WriteLine();
            }
        }

        /// <summary>
        /// Porównuje dwóch klientów na podstawie nazwiska, a jeśli nazwiska są takie same, to na podstawie imienia.
        /// Zaimplementowane z interfejsu <see cref="IComparable{Klient}"/>.
        /// </summary>
        /// <param name="other">Inny klient, z którym porównujemy bieżącego klienta.</param>
        /// <returns>Wartość ujemną, jeśli bieżący klient jest mniejszy, dodatnią, jeśli większy, lub 0, jeśli klienci są równi.</returns>
        public int CompareTo(Klient? other)
        {
            if (other == null) return 1;

            string nazwisko1 = Nazwisko ?? string.Empty;
            string nazwisko2 = other.Nazwisko ?? string.Empty;

            int nazwiskoComparison = string.Compare(nazwisko1, nazwisko2, StringComparison.Ordinal);
            if (nazwiskoComparison != 0)
                return nazwiskoComparison;

            string imie1 = Imie ?? string.Empty;
            string imie2 = other.Imie ?? string.Empty;

            return string.Compare(imie1, imie2, StringComparison.Ordinal);
        }
    }
}