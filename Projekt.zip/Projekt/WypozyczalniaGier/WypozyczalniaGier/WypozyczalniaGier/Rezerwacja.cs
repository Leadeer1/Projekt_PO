﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WypozyczalniaGier;

namespace WypozyczalniaGier
{
    /// <summary>
    /// Reprezentuje rezerwację gry przez klienta w wypożyczalni.
    /// Zawiera informacje o grze, kliencie, dacie rezerwacji oraz dacie zwrotu.
    /// </summary>
    [Serializable]
    public class Rezerwacja
    {
        /// <summary>
        /// Gra, która została zarezerwowana.
        /// </summary>
        public Gra GraR { get; set; }

        /// <summary>
        /// Klient, który dokonał rezerwacji.
        /// </summary>
        public Klient KlientR { get; set; }

        /// <summary>
        /// Data dokonania rezerwacji.
        /// </summary>
        public DateTime DataR { get; set; }

        /// <summary>
        /// Opcjonalna data zwrotu gry.
        /// </summary>
        public DateTime? DataZ { get; set; }

        /// <summary>
        /// Statyczny licznik wykorzystywany do generowania unikalnych ID rezerwacji.
        /// </summary>
        private static int nextId = 1;

        /// <summary>
        /// Unikalne ID rezerwacji.
        /// </summary>
        public int IdRezerwacji { get; set; }

        /// <summary>
        /// Inicjalizuje nową rezerwację z informacjami o grze, kliencie, dacie rezerwacji oraz dacie zwrotu.
        /// </summary>
        /// <param name="gra">Gra, która została zarezerwowana.</param>
        /// <param name="klient">Klient, który dokonał rezerwacji.</param>
        /// <param name="dataR">Data dokonania rezerwacji.</param>
        /// <param name="dataZ">Data zwrotu gry (może być pusta).</param>
        public Rezerwacja(Gra gra, Klient klient, DateTime dataR, DateTime? dataZ)
        {
            GraR = gra;
            KlientR = klient;
            DataR = dataR;
            DataZ = dataZ;
            IdRezerwacji = nextId;
            nextId++;
        }

        /// <summary>
        /// Wyświetla szczegóły rezerwacji, takie jak ID, tytuł gry, imię i nazwisko klienta oraz daty rezerwacji i zwrotu.
        /// </summary>
        public void ShowInfo()
        {
            Console.Write($"Rezerwacja - ID: {IdRezerwacji}, Gra - {GraR.Tytul}, Klient - {KlientR.Imie} {KlientR.Nazwisko}, Data Rezrwacji: {DataR.ToShortDateString()}");

            if (DataZ.HasValue)
            {
                DateTime dataZwrotu = DataZ.Value;
                Console.WriteLine($", Data Zwrotu - {dataZwrotu.ToShortDateString()}");
            }
            else
            {
                Console.WriteLine();
            }
        }
    }
}