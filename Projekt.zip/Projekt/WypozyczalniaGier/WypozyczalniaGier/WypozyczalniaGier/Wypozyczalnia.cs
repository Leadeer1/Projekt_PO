﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace WypozyczalniaGier
{
    /// <summary>
    /// Reprezentuje wypożyczalnię gier, zawierającą gry, klientów i rezerwacje.
    /// </summary>
    public class Wypozyczalnia
    {
        /// <summary>
        /// Lista przechowująca dostępne gry.
        /// </summary>
        private List<Gra> gry = new List<Gra>();

        /// <summary>
        /// Lista przechowująca zarejestrowanych klientów.
        /// </summary>
        private List<Klient> klienci = new List<Klient>();

        /// <summary>
        /// Lista przechowująca wszystkie rezerwacje.
        /// </summary>
        private List<Rezerwacja> rezerwacje = new List<Rezerwacja>();

        /// <summary>
        /// Właściwość dostępu do listy klientów.
        /// </summary>
        public List<Klient> Klienci { get => klienci; private set => klienci = value; }

        /// <summary>
        /// Właściwość dostępu do listy gier.
        /// </summary>
        public List<Gra> Gry { get => gry; set => gry = value; }

        /// <summary>
        /// Właściwość dostępu do listy rezerwacji.
        /// </summary>
        public List<Rezerwacja> Rezerwacje { get => rezerwacje; set => rezerwacje = value; }

        // Definicja wyjątków, które mogą wystąpić w systemie

        /// <summary>
        /// Wyjątek rzucany, gdy brak dostępnych egzemplarzy gry.
        /// </summary>
        public class BrakEgzemplarzyException : Exception
        {
            public BrakEgzemplarzyException(string message) : base(message) { }
        }

        /// <summary>
        /// Wyjątek rzucany, gdy obiekt nie został znaleziony.
        /// </summary>
        public class ObiektNieznalezionyException : Exception
        {
            public ObiektNieznalezionyException(string message) : base(message) { }
        }

        /// <summary>
        /// Wyjątek rzucany, gdy akcja jest niedostępna (np. próba oddania już oddanej gry).
        /// </summary>
        public class NiedostepnaAkcjaException : Exception
        {
            public NiedostepnaAkcjaException(string message) : base(message) { }
        }

        // Metody dodawania obiektów do kolekcji

        /// <summary>
        /// Dodaje grę do listy gier w wypożyczalni.
        /// </summary>
        /// <param name="gra">Gra do dodania.</param>
        public void DodajGre(Gra gra)
        {
            Gry.Add(gra);
        }

        /// <summary>
        /// Dodaje klienta do listy klientów w wypożyczalni.
        /// </summary>
        /// <param name="klient">Klient do dodania.</param>
        public void DodajKlienta(Klient klient)
        {
            Klienci.Add(klient);
        }

        /// <summary>
        /// Dodaje rezerwację, zmniejszając dostępność gry o 1.
        /// </summary>
        /// <param name="rezerwacja">Rezerwacja do dodania.</param>
        public void DodajRezerwacje(Rezerwacja rezerwacja)
        {
            if (rezerwacja.GraR.Dostepnosc > 0)
            {
                rezerwacje.Add(rezerwacja);
                rezerwacja.GraR.Dostepnosc--;
                if (rezerwacja.KlientR.liczbaWypozyczen > 0)
                {
                    rezerwacja.KlientR.IsActive = true;
                }

                Console.WriteLine($"Rezerwacja nr {rezerwacja.IdRezerwacji} dodana.");
            }
            else
            {
                throw new BrakEgzemplarzyException("Brak dostępnych egzemplarzy tej gry.");
            }
        }

        // Metody związane ze zwrotem gier

        /// <summary>
        /// Zwraca grę, zwiększając jej dostępność o 1.
        /// </summary>
        /// <param name="id">ID rezerwacji do zwrócenia.</param>
        public void ZwrocGre(int id)
        {
            if (id >= rezerwacje.Count || id < 0)
            {
                throw new NiedostepnaAkcjaException("Próbujesz zakończyć nieistniejące zamówienie.");
            }

            var rezerwacja = rezerwacje[id];
            if (rezerwacja.DataZ.HasValue)
            {
                throw new NiedostepnaAkcjaException("Próbujesz oddać oddaną grę.");
            }

            rezerwacja.KlientR.liczbaWypozyczen--;
            rezerwacja.DataZ = DateTime.Now;
            rezerwacja.GraR.Dostepnosc++;

            var aktywneRezerwacje = rezerwacje.Where(r => r.KlientR == rezerwacja.KlientR && !r.DataZ.HasValue).ToList();

            if (aktywneRezerwacje.Count == 0)
            {
                rezerwacja.KlientR.IsActive = false;
            }

            Console.WriteLine($"Dostępność gry po zwrocie: {rezerwacja.GraR.Dostepnosc}");
        }

        // Metody usuwania obiektów

        /// <summary>
        /// Usuwa klienta z listy, jeśli nie ma aktywnych rezerwacji.
        /// </summary>
        /// <param name="klient">Klient do usunięcia.</param>
        public void UsunKlienta(Klient klient)
        {
            if (Rezerwacje.Any(r => r.KlientR == klient && !r.DataZ.HasValue))
            {
                throw new InvalidOperationException("Klient ma aktywne rezerwacje i nie może zostać usunięty.");
            }

            Klienci.Remove(klient);
        }

        /// <summary>
        /// Usuwa grę z listy gier.
        /// </summary>
        /// <param name="gra">Gra do usunięcia.</param>
        public void UsunGre(Gra gra) => Gry.Remove(gra);

        /// <summary>
        /// Usuwa rezerwację z listy rezerwacji.
        /// </summary>
        /// <param name="rezerwacja">Rezerwacja do usunięcia.</param>
        public void UsunRezerwacje(Rezerwacja rezerwacja) => Rezerwacje.Remove(rezerwacja);

        // Metody wyszukiwania obiektów

        /// <summary>
        /// Wyszukuje klienta po ID.
        /// </summary>
        /// <param name="idKlienta">ID klienta do wyszukania.</param>
        /// <returns>Obiekt klienta.</returns>
        public Klient ZnajdzKlienta(int idKlienta)
        {
            var klient = Klienci.Find(k => k.IdKlienta == idKlienta);
            if (klient == null)
            {
                throw new ObiektNieznalezionyException("Klient o podanym ID nie został znaleziony.");
            }
            return klient;
        }

        /// <summary>
        /// Wyszukuje grę po tytule.
        /// </summary>
        /// <param name="tytul">Tytuł gry do wyszukania.</param>
        /// <returns>Obiekt gry.</returns>
        public Gra ZnajdzGre(string tytul)
        {
            var gra = Gry.Find(g => g.Tytul.Equals(tytul, StringComparison.OrdinalIgnoreCase));
            if (gra == null)
            {
                throw new ObiektNieznalezionyException("Nie znaleziono gry o podanym tytule.");
            }
            return gra;
        }

        // Metody wyświetlania obiektów

        /// <summary>
        /// Wyświetla dostępne gry.
        /// </summary>
        public void WyswietlGry()
        {
            Console.WriteLine("Dostępne gry:");
            foreach (var gra in gry)
            {
                gra.ShowInfo();
            }
        }

        /// <summary>
        /// Wyświetla zarejestrowanych klientów.
        /// </summary>
        public void WyswietlKlientow()
        {
            Console.WriteLine("Zarejestrowani klienci:");
            foreach (var klient in Klienci)
            {
                klient.ShowInfo();
            }
        }

        /// <summary>
        /// Wyświetla listę wszystkich rezerwacji.
        /// </summary>
        public void WyswietlRezerwacje()
        {
            Console.WriteLine("Lista rezerwacji:");
            foreach (var rezerwacja in Rezerwacje)
            {
                rezerwacja.ShowInfo();
            }
        }

        // Metody zapisu i odczytu danych

        /// <summary>
        /// Zapisuje dane wypożyczalni do pliku XML.
        /// </summary>
        /// <param name="nazwa">Nazwa pliku.</param>
        public void ZapiszXML(string nazwa)
        {
            try
            {
                using StreamWriter sr = new(nazwa);
                XmlSerializer serializer = new(typeof(Wypozyczalnia));
                serializer.Serialize(sr, this);
                Console.WriteLine("Zapisano");
                Console.WriteLine($"Plik zapisany w lokalizacji: {Path.GetFullPath(nazwa)}");
            }
            catch (InvalidOperationException ex)
            {
                Console.WriteLine($"Błąd podczas zapisu XML: {ex.Message}");
                if (ex.InnerException != null)
                {
                    Console.WriteLine($"Szczegóły: {ex.InnerException.Message}");
                }
            }
        }

        /// <summary>
        /// Odczytuje dane wypożyczalni z pliku XML.
        /// </summary>
        /// <param name="nazwa">Nazwa pliku.</param>
        /// <returns>Obiekt wypożyczalni lub null, jeśli plik nie istnieje.</returns>
        public static Wypozyczalnia? OdczytajXML(string nazwa)
        {
            if (!File.Exists(nazwa))
            {
                Console.WriteLine($"Plik {nazwa} nie istnieje");
                return null;
            }
            try
            {
                using StreamReader sw = new(nazwa);
                XmlSerializer serializer = new(typeof(Wypozyczalnia));
                return serializer.Deserialize(sw) as Wypozyczalnia;
            }
            catch (InvalidOperationException ex)
            {
                Console.WriteLine($"Błąd podczas odczytu XML: {ex.Message}");
                if (ex.InnerException != null)
                {
                    Console.WriteLine($"Szczegóły: {ex.InnerException.Message}");
                }
                return null;
            }
        }

        /// <summary>
        /// Zapisuje dane wypożyczalni do pliku JSON.
        /// </summary>
        /// <param name="sciezka">Ścieżka do pliku (opcjonalna).</param>
        public void ZapiszDane(string? sciezka)
        {
            if (string.IsNullOrEmpty(sciezka))
            {
                sciezka = "plik.json";
            }
            var dane = new { Gry = gry, Klienci = Klienci, Rezerwacje = rezerwacje };
            File.WriteAllText(sciezka, JsonSerializer.Serialize(dane));
            Console.WriteLine("Dane zapisane do pliku.");
        }

        /// <summary>
        /// Wczytuje dane wypożyczalni z pliku JSON.
        /// </summary>
        /// <param name="sciezka">Ścieżka do pliku (opcjonalna).</param>
        public void WczytajDane(string? sciezka)
        {
            if (string.IsNullOrEmpty(sciezka))
            {
                sciezka = "plik.json";
            }
            if (File.Exists(sciezka))
            {
                var dane = JsonSerializer.Deserialize<dynamic>(File.ReadAllText(sciezka));
                Console.WriteLine("Dane wczytane z pliku.");
            }
            else
            {
                Console.WriteLine("Plik nie istnieje.");
            }
        }
    }
}