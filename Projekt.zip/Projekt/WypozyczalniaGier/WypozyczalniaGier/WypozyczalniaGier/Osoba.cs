﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WypozyczalniaGier
{
    /// <summary>
    /// Abstrakcyjna klasa reprezentująca osobę, która posiada imię i nazwisko.
    /// Służy jako baza do innych klas, które dziedziczą po niej (np. Klient).
    /// </summary>
    public abstract class Osoba
    {
        /// <summary>
        /// Imię osoby.
        /// </summary>
        private string imie;

        /// <summary>
        /// Nazwisko osoby.
        /// </summary>
        private string nazwisko;

        /// <summary>
        /// Właściwość zwracająca pełne imię i nazwisko osoby w formacie: "Imię Nazwisko".
        /// </summary>
        public string ImieNazwisko => $"{imie} {nazwisko}";

        /// <summary>
        /// Właściwość do ustawiania i pobierania imienia osoby.
        /// </summary>
        public string Imie
        {
            get => imie;
            set => imie = value;
        }

        /// <summary>
        /// Właściwość do ustawiania i pobierania nazwiska osoby.
        /// </summary>
        public string Nazwisko
        {
            get => nazwisko;
            set => nazwisko = value;
        }

        /// <summary>
        /// Konstruktor domyślny.
        /// </summary>
        public Osoba()
        {
        }

        /// <summary>
        /// Konstruktor inicjalizujący imię i nazwisko osoby.
        /// </summary>
        /// <param name="imie">Imię osoby.</param>
        /// <param name="nazwisko">Nazwisko osoby.</param>
        public Osoba(string imie, string nazwisko)
        {
            Imie = imie;
            Nazwisko = nazwisko;
        }

        /// <summary>
        /// Wyświetla informacje o osobie, takie jak jej imię i nazwisko.
        /// </summary>
        public virtual void ShowInfo()
        {
            Console.WriteLine($"Imię: {Imie}, Nazwisko: {Nazwisko}");
        }
    }
}