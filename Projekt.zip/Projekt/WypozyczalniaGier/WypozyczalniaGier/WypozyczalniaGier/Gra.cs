﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WypozyczalniaGier;

namespace WypozyczalniaGier
{
    /// <summary>
    /// Reprezentuje grę dostępną w wypożyczalni.
    /// </summary>
    [Serializable]
    public class Gra : IEquatable<Gra>, ICloneable
    {
        private string tytul;
        private string gatunek;
        private int dostepnosc;

        /// <summary>
        /// Tytuł gry.
        /// </summary>
        public string Tytul { get => tytul; set => tytul = value; }

        /// <summary>
        /// Gatunek gry.
        /// </summary>
        public string Gatunek { get => gatunek; set => gatunek = value; }

        /// <summary>
        /// Liczba dostępnych egzemplarzy gry.
        /// </summary>
        public int Dostepnosc { get => dostepnosc; set => dostepnosc = value; }

        /// <summary>
        /// Inicjalizuje nową instancję klasy <see cref="Gra"/>.
        /// </summary>
        public Gra()
        {
        }

        /// <summary>
        /// Inicjalizuje nową instancję klasy <see cref="Gra"/> z określonymi wartościami.
        /// </summary>
        /// <param name="tytul">Tytuł gry.</param>
        /// <param name="gatunek">Gatunek gry.</param>
        /// <param name="liczba">Liczba dostępnych egzemplarzy gry.</param>
        public Gra(string tytul, string gatunek, int liczba)
        {
            Tytul = tytul;
            Gatunek = gatunek;
            Dostepnosc = liczba;
        }

        /// <summary>
        /// Wyświetla informacje o grze w konsoli.
        /// </summary>
        public void ShowInfo()
        {
            Console.WriteLine($"Gra: {Tytul}, Gatunek: {Gatunek}, Dostepne egzemplarze {Dostepnosc}");
        }

        /// <summary>
        /// Porównuje obecną grę z inną grą.
        /// </summary>
        /// <param name="other">Gra do porównania.</param>
        /// <returns>
        /// <c>true</c> jeśli tytuł i gatunek obu gier są takie same; w przeciwnym razie <c>false</c>.
        /// </returns>
        public bool Equals(Gra? other)
        {
            if (other == null)
                return false;

            return this.Tytul == other.Tytul && this.Gatunek == other.Gatunek;
        }

        /// <summary>
        /// Tworzy nową kopię bieżącej gry.
        /// </summary>
        /// <returns>Nowa instancja klasy <see cref="Gra"/> będąca kopią bieżącej instancji.</returns>
        public object Clone()
        {
            return new Gra(this.Tytul, this.Gatunek, this.Dostepnosc);
        }
    }
}
