﻿using System;
using System.Windows;
using WypozyczalniaGier;

namespace WpfApp2
{
    public partial class AddGameWindow : Window
    {
        private Wypozyczalnia wypozyczalnia;

        // Konstruktor przyjmujący instancję Wypozyczalnia
        public AddGameWindow(Wypozyczalnia wypozyczalnia)
        {
            InitializeComponent();
            this.wypozyczalnia = wypozyczalnia;  // Przypisanie obiektu wypożyczalni
        }

        // Obsługuje kliknięcie przycisku dodawania gry
        private void AddGame_Click(object sender, RoutedEventArgs e)
        {
            string tytul = txtTytul.Text;
            string gatunek = txtGatunek.Text;
            int dostepnosc;

            if (int.TryParse(txtDostepnosc.Text, out dostepnosc) && !string.IsNullOrEmpty(tytul) && !string.IsNullOrEmpty(gatunek))
            {
                // Tworzymy nową grę
                Gra nowaGra = new Gra(tytul, gatunek, dostepnosc);

                // Dodajemy grę do wypożyczalni
                wypozyczalnia.DodajGre(nowaGra);

                // Zaktualizowanie listy w MainWindow
                MainWindow mainWindow = (MainWindow)Application.Current.MainWindow;
                mainWindow.UpdateListBoxes();

                // Zamykamy okno
                this.Close();
            }
            else
            {
                MessageBox.Show("Proszę wprowadzić poprawną liczbę dostępności.");
            }
        }
    }
}