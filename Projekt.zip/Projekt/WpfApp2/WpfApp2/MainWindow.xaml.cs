﻿using System;
using System.Linq;
using System.Windows;
using WypozyczalniaGier;

namespace WpfApp2
{
    public partial class MainWindow : Window
    {
        private Wypozyczalnia wypozyczalnia;

        public MainWindow()
        {
            InitializeComponent();

            // Inicjalizacja obiektu wypożyczalni
            wypozyczalnia = new Wypozyczalnia();

            // Dodaj przykładowe dane
            wypozyczalnia.DodajGre(new Gra("Monopoly", "Familijne", 5));
            wypozyczalnia.DodajGre(new Gra("Dixit", "Kreatywne", 3));
            wypozyczalnia.DodajKlienta(new Klient("Jan", "Kowalski"));
            wypozyczalnia.DodajKlienta(new Klient("Anna", "Nowak"));
            wypozyczalnia.DodajRezerwacje(new Rezerwacja(wypozyczalnia.Gry[0], wypozyczalnia.Klienci[0], DateTime.Now, null));

            UpdateListBoxes();
        }

        // Metoda aktualizująca ListBoxy
        public void UpdateListBoxes()
        {
            lstGry.Items.Clear();
            lstKlienci.Items.Clear();
            lstRezerwacje.Items.Clear();

            foreach (var gra in wypozyczalnia.Gry)
            {
                lstGry.Items.Add($"Tytuł: {gra.Tytul}, Gatunek: {gra.Gatunek}, Dostępność: {gra.Dostepnosc}");
            }

            foreach (var klient in wypozyczalnia.Klienci)
            {
                string aktywnosc = klient.IsActive ? "Aktywny" : "Nieaktywny";
                lstKlienci.Items.Add($"ID: {klient.IdKlienta}, Imię: {klient.Imie}, Nazwisko: {klient.Nazwisko}, Status: {aktywnosc}");
            }

            foreach (var rezerwacja in wypozyczalnia.Rezerwacje)
            {
                string zwrot = rezerwacja.DataZ.HasValue ? $"Zwrot: {rezerwacja.DataZ.Value.ToShortDateString()}" : "Brak zwrotu";
                lstRezerwacje.Items.Add($"ID: {rezerwacja.IdRezerwacji}, Gra: {rezerwacja.GraR.Tytul}, Klient: {rezerwacja.KlientR.Imie} {rezerwacja.KlientR.Nazwisko}, {zwrot}");
            }
        }

        // Obsługuje kliknięcie przycisku dodawania gry
        private void AddGame_Click(object sender, RoutedEventArgs e)
        {
            // Tworzymy nowe okno do dodawania gry i przekazujemy wypożyczalnię
            AddGameWindow addGameWindow = new AddGameWindow(wypozyczalnia);
            addGameWindow.Show();
        }

        // Podobnie dla klientów i rezerwacji
        private void AddClient_Click(object sender, RoutedEventArgs e)
        {
            AddClientWindow addClientWindow = new AddClientWindow(wypozyczalnia);
            addClientWindow.Show();
        }

        private void AddReservation_Click(object sender, RoutedEventArgs e)
        {
            AddReservationWindow addReservationWindow = new AddReservationWindow(wypozyczalnia);
            addReservationWindow.Show();
        }

        // Usuwanie gry
        private void RemoveGame_Click(object sender, RoutedEventArgs e)
        {
            if (lstGry.SelectedIndex >= 0)
            {
                // Pobierz wybraną grę
                string selectedGame = lstGry.SelectedItem.ToString();
                string gameTitle = selectedGame.Split(", ")[0].Replace("Tytuł: ", "");

                // Znajdź obiekt gry na podstawie tytułu
                Gra graDoUsuniecia = wypozyczalnia.Gry.FirstOrDefault(g => g.Tytul == gameTitle);

                if (graDoUsuniecia != null)
                {
                    // Usuwanie gry z wypożyczalni
                    wypozyczalnia.UsunGre(graDoUsuniecia);

                    // Aktualizacja ListBox
                    UpdateListBoxes();
                }
                else
                {
                    MessageBox.Show("Nie znaleziono gry do usunięcia.");
                }
            }
            else
            {
                MessageBox.Show("Proszę wybrać grę do usunięcia.");
            }
        }

        // Usuwanie klienta
        private void DeleteClient_Click(object sender, RoutedEventArgs e)
        {
            if (lstKlienci.SelectedItem == null)
            {
                MessageBox.Show("Proszę wybrać klienta do usunięcia.");
                return;
            }

            // Pobierz wybranego klienta z listy
            int selectedIndex = lstKlienci.SelectedIndex;
            Klient klientDoUsuniecia = wypozyczalnia.Klienci[selectedIndex];

            // Sprawdź, czy klient ma aktywne rezerwacje
            if (wypozyczalnia.Rezerwacje.Any(r => r.KlientR == klientDoUsuniecia && !r.DataZ.HasValue))
            {
                MessageBox.Show("Nie można usunąć klienta, ponieważ ma aktywne rezerwacje.");
                return;
            }

            // Usuń klienta z wypożyczalni
            wypozyczalnia.UsunKlienta(klientDoUsuniecia);

            // Odśwież listę w GUI
            UpdateListBoxes();

            MessageBox.Show("Klient został usunięty.");
        }

        // Usuwanie rezerwacji
        private void DeleteReservation_Click(object sender, RoutedEventArgs e)
        {
            if (lstRezerwacje.SelectedItem == null)
            {
                MessageBox.Show("Proszę wybrać rezerwację do usunięcia.");
                return;
            }

            // Pobierz wybraną rezerwację
            int selectedIndex = lstRezerwacje.SelectedIndex;
            Rezerwacja rezerwacjaDoUsuniecia = wypozyczalnia.Rezerwacje[selectedIndex];

            // Usuń rezerwację z wypożyczalni
            wypozyczalnia.UsunRezerwacje(rezerwacjaDoUsuniecia);

            // Odśwież listę w GUI
            UpdateListBoxes();

            MessageBox.Show("Rezerwacja została usunięta.");
        }

        // Sortowanie klientów
        private void SortClients_Click(object sender, RoutedEventArgs e)
        {
            // Sortowanie listy klientów
            wypozyczalnia.Klienci.Sort();  // Wywołuje CompareTo, który sortuje po nazwisku, a w razie równości po imieniu

            // Aktualizacja ListBoxa (klientów) po sortowaniu
            UpdateListBoxes();
        }

        // Zwrot gry
        private void ReturnGame_Click(object sender, RoutedEventArgs e)
        {
            // Sprawdzenie, czy wybrano jakąkolwiek rezerwację
            if (lstRezerwacje.SelectedItem == null)
            {
                MessageBox.Show("Proszę wybrać rezerwację do zwrócenia.");
                return;
            }

            // Pobranie wybranej rezerwacji
            string selectedReservation = lstRezerwacje.SelectedItem.ToString();
            string reservationId = selectedReservation.Split(", ")[0].Replace("ID: ", "");
            int reservationIdInt = int.Parse(reservationId);

            // Znalezienie rezerwacji
            Rezerwacja rezerwacjaDoZwrotu = wypozyczalnia.Rezerwacje.FirstOrDefault(r => r.IdRezerwacji == reservationIdInt);

            if (rezerwacjaDoZwrotu != null)
            {
                // Sprawdzenie, czy rezerwacja jest już zwrócona
                if (rezerwacjaDoZwrotu.DataZ.HasValue)
                {
                    MessageBox.Show("Ta gra została już zwrócona.");
                }
                else
                {
                    // Ustawienie daty zwrotu
                    rezerwacjaDoZwrotu.DataZ = DateTime.Now;
                    Gra gra = wypozyczalnia.Gry.FirstOrDefault(g => g.Tytul == rezerwacjaDoZwrotu.GraR.Tytul);
                    if (gra != null)
                    {
                        gra.Dostepnosc++;
                    }

                    // Aktualizacja ListBox
                    UpdateListBoxes();

                    MessageBox.Show($"Gra '{rezerwacjaDoZwrotu.GraR.Tytul}' została zwrócona.");
                }
            }
            else
            {
                MessageBox.Show("Nie znaleziono wybranej rezerwacji.");
            }
        }
    }
}