﻿using System;
using System.Windows;
using WypozyczalniaGier;

namespace WpfApp2
{
    public partial class AddClientWindow : Window
    {
        private Wypozyczalnia wypozyczalnia;

        // Konstruktor przyjmujący instancję Wypozyczalnia
        public AddClientWindow(Wypozyczalnia wypozyczalnia)
        {
            InitializeComponent();
            this.wypozyczalnia = wypozyczalnia;  // Przypisanie obiektu wypożyczalni
        }

        // Obsługuje kliknięcie przycisku dodawania klienta
        private void AddClient_Click(object sender, RoutedEventArgs e)
        {
            string imie = txtImie.Text;
            string nazwisko = txtNazwisko.Text;

            if (!string.IsNullOrEmpty(imie) && !string.IsNullOrEmpty(nazwisko))
            {
                // Tworzymy nowego klienta
                Klient nowyKlient = new Klient(imie, nazwisko);

                // Dodajemy klienta do wypożyczalni
                wypozyczalnia.DodajKlienta(nowyKlient);

                // Zaktualizowanie listy w MainWindow
                MainWindow mainWindow = (MainWindow)Application.Current.MainWindow;
                mainWindow.UpdateListBoxes();  // Zaktualizowanie list po dodaniu klienta

                // Zamykamy okno
                this.Close();
            }
            else
            {
                MessageBox.Show("Proszę wprowadzić imię i nazwisko klienta.");
            }
        }
    }
}