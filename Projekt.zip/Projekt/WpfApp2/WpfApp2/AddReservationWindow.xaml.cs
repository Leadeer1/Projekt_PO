﻿using System;
using System.Windows;
using WypozyczalniaGier;

namespace WpfApp2
{
    public partial class AddReservationWindow : Window
    {
        private Wypozyczalnia wypozyczalnia;

        // Konstruktor przyjmujący instancję Wypozyczalnia
        public AddReservationWindow(Wypozyczalnia wypozyczalnia)
        {
            InitializeComponent();
            this.wypozyczalnia = wypozyczalnia;  // Przypisanie obiektu wypożyczalni

            // Przypisanie źródeł danych dla ComboBoxów
            cmbGry.ItemsSource = wypozyczalnia.Gry; // Lista gier z Wypozyczalnia
            cmbKlienci.ItemsSource = wypozyczalnia.Klienci; // Lista klientów z Wypozyczalnia
        }

        // Obsługuje kliknięcie przycisku dodawania rezerwacji
        private void AddReservation_Click(object sender, RoutedEventArgs e)
        {
            if (cmbGry.SelectedItem != null && cmbKlienci.SelectedItem != null && dpDataRezerwacji.SelectedDate.HasValue)
            {
                Gra graWybrana = (Gra)cmbGry.SelectedItem;
                Klient klientWybrany = (Klient)cmbKlienci.SelectedItem;
                DateTime dataRezerwacji = dpDataRezerwacji.SelectedDate.Value;

                if (graWybrana.Dostepnosc > 0)
                {
                    // Tworzymy nową rezerwację
                    Rezerwacja nowaRezerwacja = new Rezerwacja(graWybrana, klientWybrany, dataRezerwacji, null);

                    // Dodajemy rezerwację do wypożyczalni
                    wypozyczalnia.DodajRezerwacje(nowaRezerwacja);
                  

                    // Zaktualizowanie listy w MainWindow
                    MainWindow mainWindow = (MainWindow)Application.Current.MainWindow;
                    mainWindow.UpdateListBoxes();

                    // Zamykamy okno
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Gra jest niedostępna.");
                }
            }
            else
            {
                MessageBox.Show("Proszę wybrać grę, klienta oraz datę rezerwacji.");
            }
        }
    }
}