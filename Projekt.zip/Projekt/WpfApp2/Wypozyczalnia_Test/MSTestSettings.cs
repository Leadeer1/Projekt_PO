﻿using WypozyczalniaGier;

namespace TestyWypozyczalniaGier
{

    [TestClass]  
    public class GraTests
    {

        [TestMethod]  
        public void TestKonstruktorBezParametrow()
        {
            // Arrange: Tworzymy instancję klasy Gra
            Gra gra = new Gra();

            // Act & Assert: Sprawdzamy, czy właściwości mają domyślne wartości
            Assert.IsNotNull(gra);  // Upewniamy się, że obiekt został utworzony
            Assert.AreEqual(null, gra.Tytul);  // Sprawdzamy, czy Tytul jest null
            Assert.AreEqual(null, gra.Gatunek);  // Sprawdzamy, czy Gatunek jest null
            Assert.AreEqual(0, gra.Dostepnosc);  // Sprawdzamy, czy Dostepnosc wynosi 0
        }


        [TestMethod]
        public void TestKonstruktorZParametrami()
        {
            // Arrange: Przekazujemy wartości do konstruktora
            string tytul = "Wiedźmin 3";
            string gatunek = "RPG";
            int dostepnosc = 5;

            // Act: Tworzymy obiekt z tymi parametrami
            Gra gra = new Gra(tytul, gatunek, dostepnosc);

            // Assert: Sprawdzamy, czy właściwości są ustawione poprawnie
            Assert.AreEqual(tytul, gra.Tytul);  // Sprawdzamy Tytul
            Assert.AreEqual(gatunek, gra.Gatunek);  // Sprawdzamy Gatunek
            Assert.AreEqual(dostepnosc, gra.Dostepnosc);  // Sprawdzamy Dostepnosc
        }


        [TestMethod]
        public void TestShowInfo()
        {
            // Arrange: Tworzymy obiekt Gra
            string tytul = "Cyberpunk 2077";
            string gatunek = "Action RPG";
            int dostepnosc = 3;
            Gra gra = new Gra(tytul, gatunek, dostepnosc);

            // Act: Przechwytujemy wyjście na konsolę
            using (var sw = new StringWriter())
            {
                Console.SetOut(sw);  // Ustawiamy przechwytywanie konsoli
                gra.ShowInfo();  // Wywołujemy metodę ShowInfo
                var wynik = sw.ToString().Trim();  // Pobieramy wynik

                // Assert: Porównujemy wynik z oczekiwanym
                string oczekiwanyWynik = $"Gra: {tytul}, Gatunek: {gatunek}, Dostepne egzemplarze {dostepnosc}";
                Assert.AreEqual(oczekiwanyWynik, wynik);  // Sprawdzamy, czy wynik jest zgodny
            }
        }

        [TestMethod]
        public void PowinnoZwracacTrue_GdyGryMajaTytulIGatunek()
        {
            // Arrange
            var gra1 = new Gra("The Witcher 3", "RPG", 10);
            var gra2 = new Gra("The Witcher 3", "RPG", 5);

            // Act
            var wynik = gra1.Equals(gra2);

            // Assert
            Assert.IsTrue(wynik);  // Sprawdzamy, czy metoda Equals zwróciła true
        }

        [TestMethod]
        public void PowinnoZwracacFalse_GdyGryMajaRozneTytuly()
        {
            // Arrange
            var gra1 = new Gra("The Witcher 3", "RPG", 10);
            var gra2 = new Gra("Cyberpunk 2077", "RPG", 5);

            // Act
            var wynik = gra1.Equals(gra2);

            // Assert
            Assert.IsFalse(wynik);  // Sprawdzamy, czy metoda Equals zwróciła false
        }

        [TestMethod]
        public void PowinnoZwracacFalse_GdyGryMajaRozneGatunki()
        {
            // Arrange
            var gra1 = new Gra("The Witcher 3", "RPG", 10);
            var gra2 = new Gra("The Witcher 3", "Action", 5);

            // Act
            var wynik = gra1.Equals(gra2);

            // Assert
            Assert.IsFalse(wynik);  // Sprawdzamy, czy metoda Equals zwróciła false
        }

        [TestMethod]
        public void PowinnoZwracacFalse_GdyPorownywanaGraToNull()
        {
            // Arrange
            var gra1 = new Gra("The Witcher 3", "RPG", 10);

            // Act
            var wynik = gra1.Equals(null);

            // Assert
            Assert.IsFalse(wynik);  // Sprawdzamy, czy metoda Equals zwróciła false dla null
        }

        [TestMethod]
        public void TestClone()
        {
            // Arrange: Tworzymy obiekt Gra
            Gra originalGra = new Gra("Monopoly", "Planszowa", 10);

            // Act: Klonujemy oryginalną grę
            Gra clonedGra = (Gra)originalGra.Clone();

            // Assert: Sprawdzamy, czy klon jest różny od oryginału, ale mają te same właściwości
            Assert.AreNotSame(originalGra, clonedGra, "Klonowana gra nie powinna być tym samym obiektem co oryginał.");
            Assert.AreEqual(originalGra.Tytul, clonedGra.Tytul, "Tytuły gier powinny być takie same.");
            Assert.AreEqual(originalGra.Gatunek, clonedGra.Gatunek, "Gatunki gier powinny być takie same.");
            Assert.AreEqual(originalGra.Dostepnosc, clonedGra.Dostepnosc, "Dostępność gier powinna być taka sama.");
        }
    }
    




    [TestClass]
    public class OsobaTests
    {
        // Klasa testowa, ponieważ Osoba jest klasą abstrakcyjną
        public class OsobaTestowa : Osoba
        {
            public OsobaTestowa(string imie, string nazwisko) : base(imie, nazwisko)
            {
            }

            public override void ShowInfo()
            {
                // Przełamujemy metodę ShowInfo, żeby tylko ją testować
                base.ShowInfo();
            }
        }

        [TestMethod]
        public void TestKonstruktorBezParametrow()
        {
            // Arrange: Tworzymy instancję klasy OsobaTestowa
            OsobaTestowa osoba = new OsobaTestowa(null, null);

            // Assert: Sprawdzamy, czy właściwości mają domyślne wartości
            Assert.IsNull(osoba.Imie);  // Imie powinno być null
            Assert.IsNull(osoba.Nazwisko);  // Nazwisko powinno być null
        }

        [TestMethod]
        public void TestKonstruktorZParametrami()
        {
            // Arrange: Przekazujemy wartości do konstruktora
            string imie = "Jan";
            string nazwisko = "Kowalski";

            // Act: Tworzymy obiekt z tymi parametrami
            OsobaTestowa osoba = new OsobaTestowa(imie, nazwisko);

            // Assert: Sprawdzamy, czy właściwości są ustawione poprawnie
            Assert.AreEqual(imie, osoba.Imie);  // Imie powinno być Jan
            Assert.AreEqual(nazwisko, osoba.Nazwisko);  // Nazwisko powinno być Kowalski
        }

        [TestMethod]
        public void TestImieNazwisko()
        {
            // Arrange: Tworzymy obiekt z imieniem i nazwiskiem
            string imie = "Anna";
            string nazwisko = "Nowak";
            OsobaTestowa osoba = new OsobaTestowa(imie, nazwisko);

            // Act: Pobieramy pełne imię i nazwisko
            string imieNazwisko = osoba.ImieNazwisko;

            // Assert: Sprawdzamy, czy pełne imię i nazwisko jest poprawne
            Assert.AreEqual("Anna Nowak", imieNazwisko);  // Powinno zwrócić "Anna Nowak"
        }

        [TestMethod]
        public void TestShowInfo()
        {
            // Arrange: Tworzymy obiekt OsobaTestowa
            string imie = "Piotr";
            string nazwisko = "Kowalski";
            OsobaTestowa osoba = new OsobaTestowa(imie, nazwisko);

            // Act: Przechwytujemy wyjście na konsolę
            using (var sw = new StringWriter())
            {
                Console.SetOut(sw);  // Ustawiamy przechwytywanie konsoli
                osoba.ShowInfo();  // Wywołujemy metodę ShowInfo
                var wynik = sw.ToString().Trim();  // Pobieramy wynik

                // Assert: Porównujemy wynik z oczekiwanym
                string oczekiwanyWynik = $"Imię: {imie}, Nazwisko: {nazwisko}";
                Assert.AreEqual(oczekiwanyWynik, wynik);  // Sprawdzamy, czy wynik jest zgodny
            }
        }
    }


    [TestClass]
    public class KlientTests
    {
        [TestInitialize]
        public void Initialize()
        {
            
            typeof(Klient)
                .GetField("nextId", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static)
                .SetValue(null, 1);
        }

        [TestMethod]
        public void TestKonstruktorBezParametrow()
        {
            // Arrange: Tworzymy instancję klasy Klient
            Klient klient = new Klient();

            // Assert: Sprawdzamy właściwości domyślne
            Assert.AreEqual(1, klient.IdKlienta, "ID klienta powinno być 1.");
            Assert.IsFalse(klient.IsActive, "Klient powinien być nieaktywny.");
            Assert.AreEqual(1, klient.liczbaWypozyczen, "Liczba wypożyczeń powinna wynosić 1.");
        }

        [TestMethod]
        public void TestKonstruktorZParametrami()
        {
            // Arrange: Przekazujemy wartości do konstruktora
            string imie = "Jan";
            string nazwisko = "Kowalski";

            // Act: Tworzymy obiekt Klient
            Klient klient = new Klient(imie, nazwisko);

            // Assert: Sprawdzamy właściwości
            Assert.AreEqual(imie, klient.Imie, "Imię klienta powinno być Jan.");
            Assert.AreEqual(nazwisko, klient.Nazwisko, "Nazwisko klienta powinno być Kowalski.");
            Assert.IsFalse(klient.IsActive, "Klient powinien być nieaktywny.");
            Assert.AreEqual(1, klient.IdKlienta, "ID klienta powinno być 1.");
        }

        [TestMethod]
        public void TestShowInfo()
        {
            // Arrange: Tworzymy obiekt Klient
            string imie = "Anna";
            string nazwisko = "Nowak";
            Klient klient = new Klient(imie, nazwisko);

            // Act: Przechwytujemy wyjście konsoli
            using (var sw = new StringWriter())
            {
                Console.SetOut(sw);
                klient.ShowInfo();
                var wynik = sw.ToString().Trim();

                // Assert: Sprawdzamy wynik
                string oczekiwanyWynik = $"Klient - ID: 1, Imię: {imie}, Nazwisko: {nazwisko}, Aktywne wypożyczenia: Nie";
                Assert.AreEqual(oczekiwanyWynik, wynik, "Wynik ShowInfo nie jest zgodny z oczekiwaniami.");
            }
        }

        [TestMethod]
        public void TestCompareTo()
        {
            // Arrange
            Klient klient1 = new Klient("Jan", "Kowalski");
            Klient klient2 = new Klient("Anna", "Nowak");
            Klient klient3 = new Klient("Jan", "Kowalski");

            // Act & Assert
            Assert.AreEqual(0, klient1.CompareTo(klient3), "Klient1 i Klient3 powinni być równi.");
            Assert.IsTrue(klient1.CompareTo(klient2) < 0, "Klient1 powinien być mniejszy od Klient2.");
            Assert.IsTrue(klient2.CompareTo(klient1) > 0, "Klient2 powinien być większy od Klient1.");
        }
    }




    [TestClass]
    public class RezerwacjaTests
    {
        [TestInitialize]
        public void ResetNextId()
        {
            typeof(Rezerwacja)
                .GetField("nextId", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static)
                .SetValue(null, 1);
        }

        [TestMethod]
        public void TestKonstruktorRezerwacja()
        {
            // Arrange: Tworzymy obiekt Gra i Klient (zakładając, że są to obiekty innych klas)
            Gra gra = new Gra("GraTestowa", "ProducentTestowy", 2025);  // Zakładając, że Gra ma konstruktor z tytulem, producentem i rokiem
            Klient klient = new Klient("Jan", "Kowalski");

            // Act: Tworzymy rezerwację
            DateTime dataRezerwacji = new DateTime(2025, 01, 20);
            Rezerwacja rezerwacja = new Rezerwacja(gra, klient, dataRezerwacji, null);

            // Assert: Sprawdzamy, czy właściwości zostały poprawnie przypisane
            Assert.AreEqual(gra, rezerwacja.GraR);
            Assert.AreEqual(klient, rezerwacja.KlientR);
            Assert.AreEqual(dataRezerwacji, rezerwacja.DataR);
            Assert.AreEqual(null, rezerwacja.DataZ);  // DataZ powinna być null w tym przypadku
            Assert.AreEqual(1, rezerwacja.IdRezerwacji);  // Pierwsza rezerwacja powinna mieć ID 1
        }

        [TestMethod]
        public void TestShowInfoZDataZ()
        {
            // Arrange
            Gra gra = new Gra("GraTestowa", "ProducentTestowy", 2025);
            Klient klient = new Klient("Jan", "Kowalski");
            DateTime dataRezerwacji = new DateTime(2025, 01, 20);
            DateTime dataZwrotu = new DateTime(2025, 02, 20);

            // Act
            Rezerwacja rezerwacja = new Rezerwacja(gra, klient, dataRezerwacji, dataZwrotu);

            using (var sw = new StringWriter())
            {
                Console.SetOut(sw);
                rezerwacja.ShowInfo();
                var wynik = sw.ToString().Trim();

                // Assert
                string oczekiwanyWynik = "Rezerwacja - ID: 1, Gra - GraTestowa, Klient - Jan Kowalski, Data Rezrwacji: 20.01.2025, Data Zwrotu - 20.02.2025";
                Assert.AreEqual(oczekiwanyWynik, wynik);
            }
        }


        [TestMethod]
        public void TestShowInfoBezDataZ()
        {
            // Arrange: Tworzymy obiekt Gra i Klient
            Gra gra = new Gra("GraTestowa", "ProducentTestowy", 2025);
            Klient klient = new Klient("Jan", "Kowalski");
            DateTime dataRezerwacji = new DateTime(2025, 01, 20);

            // Act: Tworzymy rezerwację bez daty zwrotu
            Rezerwacja rezerwacja = new Rezerwacja(gra, klient, dataRezerwacji, null);

            // Przechwytujemy wyjście na konsolę
            using (var sw = new StringWriter())
            {
                Console.SetOut(sw);  // Ustawiamy przechwytywanie konsoli
                rezerwacja.ShowInfo();  // Wywołujemy metodę ShowInfo
                var wynik = sw.ToString().Trim();  // Pobieramy wynik

                // Assert: Sprawdzamy, czy wynik zawiera poprawną informację
                string oczekiwanyWynik = $"Rezerwacja - ID: 1, Gra - GraTestowa, Klient - Jan Kowalski, Data Rezrwacji: {dataRezerwacji.ToShortDateString()}";
                Assert.AreEqual(oczekiwanyWynik, wynik);  // Sprawdzamy, czy wynik jest zgodny
            }
        }
    }






    [TestClass]
    public class WypozyczalniaTest
    {
        private Wypozyczalnia wypozyczalnia;

        [TestInitialize]
        public void SetUp()
        {
            // Tworzymy instancję klasy Wypozyczalnia przed każdym testem
            wypozyczalnia = new Wypozyczalnia();
        }

        [TestMethod]
        public void TestDodajGre()
        {
            // Tworzymy obiekt gry
            Gra gra = new Gra("Gra 1", "Opis gry 1", 10);
            // Dodajemy grę do wypożyczalni
            wypozyczalnia.DodajGre(gra);

            // Sprawdzamy, czy gra została dodana
            Assert.IsTrue(wypozyczalnia.Gry.Contains(gra), "Gra nie została dodana.");
        }

        [TestMethod]
        public void TestDodajKlienta()
        {
            // Tworzymy obiekt klienta
            Klient klient = new Klient("Jan", "Kowalski");
            // Dodajemy klienta do wypożyczalni
            wypozyczalnia.DodajKlienta(klient);

            // Sprawdzamy, czy klient został dodany
            Assert.IsTrue(wypozyczalnia.Klienci.Contains(klient), "Klient nie został dodany.");
        }

        [TestMethod]
        public void TestUsunKlienta()
        {
            // Tworzymy obiekty gry i klienta
            Gra gra = new Gra("Gra 5", "Opis gry 5", 3);
            Klient klient = new Klient("Tomasz", "Biały");

            // Dodajemy grę i klienta do wypożyczalni
            wypozyczalnia.DodajGre(gra);
            wypozyczalnia.DodajKlienta(klient);

            // Tworzymy rezerwację dla klienta
            Rezerwacja rezerwacja = new Rezerwacja(gra, klient, DateTime.Now, null);
            wypozyczalnia.DodajRezerwacje(rezerwacja);

            // Testujemy, czy klient nie może zostać usunięty, gdy ma aktywne rezerwacje
            try
            {
                wypozyczalnia.UsunKlienta(klient);
                Assert.Fail("Oczekiwano wyjątku, ponieważ klient ma aktywne rezerwacje.");
            }
            catch (InvalidOperationException ex)
            {
                Assert.AreEqual("Klient ma aktywne rezerwacje i nie może zostać usunięty.", ex.Message);
            }

            // Zmieniamy status rezerwacji, ustawiając datę zwrotu
            rezerwacja.DataZ = DateTime.Now;

            // Testujemy, czy klient może zostać usunięty, gdy nie ma aktywnych rezerwacji
            wypozyczalnia.UsunKlienta(klient);

            // Sprawdzamy, czy klient został usunięty
            Assert.IsFalse(wypozyczalnia.Klienci.Contains(klient), "Klient powinien zostać usunięty.");
        }




        [TestMethod]
        public void TestDodajRezerwacje()
        {
            // Tworzymy obiekt gry i klienta
            Gra gra = new Gra("Gra 2", "Opis gry 2", 3);
            Klient klient = new Klient("Adam", "Nowak");

            // Dodajemy grę i klienta do wypożyczalni
            wypozyczalnia.DodajGre(gra);
            wypozyczalnia.DodajKlienta(klient);

            // Tworzymy rezerwację
            Rezerwacja rezerwacja = new Rezerwacja(gra, klient, DateTime.Now, null);
            // Dodajemy rezerwację
            wypozyczalnia.DodajRezerwacje(rezerwacja);

            // Sprawdzamy, czy rezerwacja została dodana
            Assert.IsTrue(wypozyczalnia.Rezerwacje.Contains(rezerwacja), "Rezerwacja nie została dodana.");
        }

        [TestMethod]
        [ExpectedException(typeof(Wypozyczalnia.BrakEgzemplarzyException))]
        public void TestDodajRezerwacjeBrakEgzemplarzy()
        {
            // Tworzymy obiekt gry z zerową liczbą egzemplarzy
            Gra gra = new Gra("Gra 3", "Opis gry 3", 0);
            Klient klient = new Klient("Marek", "Kowalski");

            // Dodajemy grę i klienta do wypożyczalni
            wypozyczalnia.DodajGre(gra);
            wypozyczalnia.DodajKlienta(klient);

            // Próba dodania rezerwacji, która powinna rzucić wyjątek
            Rezerwacja rezerwacja = new Rezerwacja(gra, klient, DateTime.Now, null);
            wypozyczalnia.DodajRezerwacje(rezerwacja);
        }

        [TestMethod]
        public void TestZwrocGre()
        {
            // Tworzymy obiekt gry i klienta
            Gra gra = new Gra("Gra 4", "Opis gry 4", 5);
            Klient klient = new Klient("Tomasz", "Biały");

            // Tworzymy obiekt wypożyczalni
            Wypozyczalnia wypozyczalnia = new Wypozyczalnia();

            // Dodajemy grę i klienta do wypożyczalni
            wypozyczalnia.DodajGre(gra);
            wypozyczalnia.DodajKlienta(klient);

            // Tworzymy rezerwację
            Rezerwacja rezerwacja = new Rezerwacja(gra, klient, DateTime.Now, null);
            wypozyczalnia.DodajRezerwacje(rezerwacja);

            // Sprawdzamy dostępność gry po dodaniu rezerwacji
            Assert.AreEqual(4, gra.Dostepnosc, "Dostępność gry powinna wynosić 4 po dodaniu rezerwacji.");

            // Zwracamy grę
            wypozyczalnia.ZwrocGre(0); // Przyjmujemy, że 0 to ID rezerwacji

            // Sprawdzamy, czy liczba dostępnych egzemplarzy gry wzrosła do 5
            Assert.AreEqual(5, gra.Dostepnosc, "Dostępność gry powinna wynosić 5 po zwróceniu gry.");
        }




        [TestMethod]
        public void TestZnajdzKlienta()
        {
            // Tworzymy obiekt klienta
            Klient klient = new Klient("Julia", "Zielona");
            // Dodajemy klienta do wypożyczalni
            wypozyczalnia.DodajKlienta(klient);

            // Szukamy klienta po ID
            Klient foundClient = wypozyczalnia.ZnajdzKlienta(klient.IdKlienta);

            // Sprawdzamy, czy klient został znaleziony
            Assert.AreEqual(klient, foundClient, "Nie znaleziono klienta.");
        }

        [TestMethod]
        public void TestZnajdzGre()
        {
            // Tworzymy obiekt gry
            Gra gra = new Gra("Gra 5", "Opis gry 5", 10);
            // Dodajemy grę do wypożyczalni
            wypozyczalnia.DodajGre(gra);

            // Szukamy gry po nazwie
            Gra foundGame = wypozyczalnia.ZnajdzGre("Gra 5");

            // Sprawdzamy, czy gra została znaleziona
            Assert.AreEqual(gra, foundGame, "Nie znaleziono gry.");
        }

        [TestMethod]
        public void TestWyswietlGry()
        {
            // Tworzymy obiekt gry
            Gra gra = new Gra("Gra 6", "Opis gry 6", 10);
            // Dodajemy grę do wypożyczalni
            wypozyczalnia.DodajGre(gra);

            // Sprawdzamy, czy gra jest w kolekcji (ten test nie sprawdza wyświetlania w konsoli)
            Assert.IsTrue(wypozyczalnia.Gry.Contains(gra), "Gra nie została wyświetlona.");
        }

        [TestMethod]
        public void TestWyswietlKlientow()
        {
            // Tworzymy obiekt klienta
            Klient klient = new Klient("Michał", "Szary");
            // Dodajemy klienta do wypożyczalni
            wypozyczalnia.DodajKlienta(klient);

            // Sprawdzamy, czy klient jest w kolekcji (ten test nie sprawdza wyświetlania w konsoli)
            Assert.IsTrue(wypozyczalnia.Klienci.Contains(klient), "Klient nie został wyświetlony.");
        }

        [TestMethod]
        public void TestWyswietlRezerwacje()
        {
            // Tworzymy obiekt gry i klienta
            Gra gra = new Gra("Gra 7", "Opis gry 7", 5);
            Klient klient = new Klient("Karol", "Biały");

            // Dodajemy grę i klienta do wypożyczalni
            wypozyczalnia.DodajGre(gra);
            wypozyczalnia.DodajKlienta(klient);

            // Tworzymy rezerwację
            Rezerwacja rezerwacja = new Rezerwacja(gra, klient, DateTime.Now, null);
            wypozyczalnia.DodajRezerwacje(rezerwacja);

            // Sprawdzamy, czy rezerwacja jest w kolekcji (ten test nie sprawdza wyświetlania w konsoli)
            Assert.IsTrue(wypozyczalnia.Rezerwacje.Contains(rezerwacja), "Rezerwacja nie została wyświetlona.");
        }

        [TestMethod]
        public void TestZapiszDane()
        {
            // Test zapisu danych (ten test nie sprawdza faktycznego zapisu na dysku)
            wypozyczalnia.ZapiszDane("dane.json");

            // Jeśli nie wystąpiły żadne błędy, to test przeszedł pomyślnie
            Assert.IsTrue(true);
        }

        [TestMethod]
        public void TestWczytajDane()
        {
            // Test wczytania danych (ten test nie sprawdza faktycznego wczytania z dysku)
            wypozyczalnia.WczytajDane("dane.json");

            // Jeśli nie wystąpiły żadne błędy, to test przeszedł pomyślnie
            Assert.IsTrue(true);
        }
    }
}





